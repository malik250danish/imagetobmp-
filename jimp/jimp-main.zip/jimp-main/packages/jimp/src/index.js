import configure from "@jimp/custom";

import types from "@jimp/types";
import plugins from "@jimp/plugins";

export default configure({
  types: [types],
  plugins: [plugins],
});
